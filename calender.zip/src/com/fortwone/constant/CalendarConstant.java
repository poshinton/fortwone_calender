package com.fortwone.constant;

public class CalendarConstant {

	public final static String[] sch_type = { "会议", "约会", "电话", "纪念日", "生日", "课程", "其他" }; // 日程类型
	public final static String[] remind = {"提醒一次","隔10分钟","隔30分钟","隔一小时","每天重复","每周重复","每月重复","每年重复"};
}
